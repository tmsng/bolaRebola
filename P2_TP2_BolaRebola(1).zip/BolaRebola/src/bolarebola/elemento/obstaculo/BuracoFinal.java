package bolarebola.elemento.obstaculo;

import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import bolarebola.elemento.Bola;
import bolarebola.elemento.Nivel;
import prof.jogos2D.image.ComponenteMultiAnimado;
import prof.jogos2D.image.ComponenteVisual;
import prof.jogos2D.util.DetectorColisoes;

/**
 * Representa o buraco final
 */
public class BuracoFinal {

	private Point2D.Double centro;
	private double raio;
	private Nivel nivel;
	private Bola bolaCaptada;
	private ComponenteVisual imagem;

	/**
	 * Cria o buraco final
	 * @param centro centro do buraco
	 * @param raio raio do buraco
	 * @param c componente visual que representa o buraco
	 */
	public BuracoFinal( Point2D.Double centro, double raio, ComponenteMultiAnimado c ){
		imagem = c;
		this.centro = centro;
		this.raio = raio; 
	}
	
	/**
	 * processa a bola a cair no buraco
	 * @param b a bola
	 */
	public void engoleBola( Bola b ){
		// se tem a bola captada � preciso ver se j� acabou a anima��o de engolir a bola
		if( temBolaCaptada() ) {
			b.setPosicaoCentro( getCentro() );
			ComponenteMultiAnimado imagem = (ComponenteMultiAnimado)getImagem();
			if( imagem.numCiclosFeitos() >= 1 ) {				
				// avisa o n�vel que a bola chegou
				getNivel().chegou();			
			}
		}
		
		// se bateu � preciso captar a bola e dar inicio � anima��o de captura
		else if( tocou( b ) ) {
			captarBola( b );
			ComponenteMultiAnimado imagem = (ComponenteMultiAnimado)getImagem();
			imagem.setAnim(1);
			imagem.reset();
			imagem.setCiclico( false );
		}
	}

	/** desenhar o buraco
	 */
	public void desenhar(Graphics2D g) {
		imagem.desenhar(g);
		if( temBolaCaptada() ) {
			// se em bola captada � preciso aplicar o efeito especial sobre a bola
			// o efeito especial � mingar a bola
			AffineTransform old = g.getTransform();
			ComponenteMultiAnimado cma = (ComponenteMultiAnimado)getImagem();
			// escalar a bola para ficar mais pequena
			double scale = ((cma.totalFrames() - cma.getFrameNum()) / (double)cma.totalFrames());
			double tx = getImagem().getPosicaoCentro().x;
			double ty = getImagem().getPosicaoCentro().y;
			g.translate(tx, ty);
			g.scale(scale, scale);
			g.translate(-tx, -ty);
			bolaCaptada.desenhar( g );			
			g.setTransform( old );
		}
	}

	public boolean tocou(Bola b) {
		return DetectorColisoes.intersectam( centro,  raio, b.getPosicaoCentro(), b.getRaio() );
	}

	public Point2D.Double getCentro() {
		return centro;
	}

	public void setCentro(Point2D.Double centro) {
		this.centro = centro;
	}

	public double getRaio() {
		return raio;
	}

	public void setRaio(double raio) {
		this.raio = raio;
	}

	public Nivel getNivel() {
		return nivel;
	}

	public void setNivel(Nivel nivel) {
		this.nivel = nivel;		
	}

	public boolean temBolaCaptada() {
		return bolaCaptada != null;
	}

	private void captarBola(Bola bolaCaptada) {
		this.bolaCaptada = bolaCaptada;
		nivel.captarBola( this, Nivel.CAPTOR_BURACO );
	}

	private void libertarBola() {
		this.bolaCaptada = null;
		nivel.libertarBola( this );
	}

	public ComponenteVisual getImagem() {
		return imagem;
	}

	public void setImagem(ComponenteMultiAnimado img) {
		this.imagem = img;
	}

	public Point getPosicaoImagem() {
		return imagem.getPosicao();
	}

	public void setPosicaoImagem(Point p) {
		imagem.setPosicao(p);
	}
}
